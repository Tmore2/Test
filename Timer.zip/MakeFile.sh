#!/bin/bash
###################################################
# デバッグ有効/無効
DebugEn=false
###################################################
if "${DebugEn}"; then
	echo [$0]引数1：$1
	echo [$0]引数2：$2
fi

# 出力ディレクトリ作成
if [ -d ./$1 ]; then
	# 存在する場合
	:	# 何もしない
else
	# 存在しない場合
	mkdir $1
fi

# 出力ファイルパス
OutputFilePath=$1/$2
if "${DebugEn}"; then
	echo [$0]OutputFilePath:$OutputFilePath
fi

# 出力ファイル作成
touch $OutputFilePath

# 文字列を追加
# グルーピング(複数コマンドを１つのコマンドとして認識)
{
	echo "・日付"				# 項目追加
	echo -e "　"`date +%Y/%m/%d[%a]`"\n"	# 日付追加(全角スペース+dateコマンドの結果+改行)
	echo -e "・実施しているAI\n"		# 項目追加+改行
	echo -e "・作業内容\n"			# 項目追加+改行
	echo -e "・作業を通して学んだこと\n"	# 項目追加+改行
	echo -e "・反省点、気づき\n"		# 項目追加+改行
} > $OutputFilePath				# リダイレクト(上書き)

# 出力ディレクトリ以下のファイル一覧を表示する
echo [$0]出力ディレクトリ以下のファイル一覧を表示
ls $1 | sort -f

exit 0



