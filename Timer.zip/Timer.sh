#!/bin/bash
####################################################################################
# デバッグ有効/無効
DebugEn=false
####################################################################################
# iniファイル読み込み
INI_FILE=setting.ini

# "="区切りの右側を取得する
InformTimes=$(awk -F "=" '/InformTimes/{print $2}' $INI_FILE)
InformInterval=$(awk -F "=" '/InformInterval/{print $2}' $INI_FILE)
Message=$(awk -F "=" '/Message/{print $2}' $INI_FILE)
OutputDir=$(awk -F "=" '/OutputDir/{print $2}' $INI_FILE)
OutputFile=$(awk -F "=" '/OutputFile/{print $2}' $INI_FILE)

if "${DebugEn}"; then
	echo [$0]InformTimes:$InformTimes
	echo [$0]InformInterval:$InformInterval
	echo [$0]Message:$Message
	echo [$0]OutputDir:$OutputDir
	echo [$0]OutputFile:$OutputFile
fi

# iniファイルの設定チェック
if [ -z "$InformTimes" ] || [ -z "$InformInterval" ] || [ -z "$Message" ] || \
   [ -z "$OutputDir" ] || [ -z "$OutputFile" ]; then
	# 設定値が空の場合
	echo [$0]$INI_FILEの設定を確認してください。
 	exit	# 終了
else
	:	# 何もしない
fi

# ファイルを作成(サブシェル)）
bash MakeFile.sh $OutputDir $OutputFile &	#&：バックグラウンド実行(並行化)

# 通知する
for (( i=0; i < $InformTimes; i++ ));
do
	# スリープ
	sleep $InformInterval
	# 通知領域にメッセージを表示する
	zenity --notification --text=$Message:通知回数[$i]
 	if "${DebugEn}"; then
 		echo [$0]$Message:通知回数[$i]
 	fi
done

exit 0

